import tensorflow as tf
from keras.models import load_model


autoencoder = load_model('/workspaces/Autoencoder-Dedup/Final Model Encoder, SSIM Loss, Loss 0.1193, MSE 0.0044.h5')
